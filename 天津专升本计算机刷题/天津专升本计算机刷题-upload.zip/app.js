const DAILY_TARGET = 100;

const STORAGE_KEYS = {
  dailyStatsMap: "tjzsb-computer-daily-stats-map",
  wrongIds: "tjzsb-computer-wrong-ids",
  categories: "tjzsb-computer-categories",
  mode: "tjzsb-computer-mode",
  shuffle: "tjzsb-computer-shuffle"
};

const weeklyPlan = [
  {
    date: "2026-05-10",
    title: "基础摸底日",
    focus: "计算机基础 + Windows",
    summary: "先做 100 题，把编码、存储、硬件组成、文件管理、常用快捷键这一层彻底吃透。",
    tags: ["100题", "基础", "看错题"]
  },
  {
    date: "2026-05-11",
    title: "办公软件一",
    focus: "Word + PowerPoint",
    summary: "重点练目录、页眉页脚、格式刷、母版、动画和切换。做完后专门回刷操作型错题。",
    tags: ["100题", "Word", "PPT"]
  },
  {
    date: "2026-05-12",
    title: "办公软件二",
    focus: "Excel",
    summary: "集中练函数、相对绝对引用、图表、排序筛选、条件格式。这一块最容易形成分差。",
    tags: ["100题", "Excel强化", "重点"]
  },
  {
    date: "2026-05-13",
    title: "网络概念日",
    focus: "网络基础 + 云计算 + 大数据",
    summary: "集中攻协议、URL、DNS、IP、安全、物联网、云计算场景，避免概念题失分。",
    tags: ["100题", "网络", "概念题"]
  },
  {
    date: "2026-05-14",
    title: "混合强化日",
    focus: "基础 + Word + Excel",
    summary: "选择 3 个高频章节混刷 100 题，训练章节切换能力，同时观察哪个模块最不稳定。",
    tags: ["100题", "混刷", "查薄弱"]
  },
  {
    date: "2026-05-15",
    title: "错题回收日",
    focus: "只刷错题 + 薄弱章节",
    summary: "当天至少拿出一半题量回收错题，不追求新题数，先把容易反复错的知识点清掉。",
    tags: ["100题", "错题本", "补漏洞"]
  },
  {
    date: "2026-05-16",
    title: "模拟巩固日",
    focus: "全章节随机",
    summary: "按正式考试节奏做 100 题，结束后写下本周最不稳的 2 个章节，下一周优先补。",
    tags: ["100题", "全章随机", "周总结"]
  }
];

const reviewAdvice = [
  {
    title: "基础概念不稳",
    text: "如果二进制、ASCII、存储单位、硬件组成错得多，后两天优先多选“计算机基础”，先把概念题刷熟。"
  },
  {
    title: "Office 操作题易混",
    text: "如果 Word、Excel、PowerPoint 的按钮位置、功能用途、快捷键总混淆，建议当天错哪块就立刻加刷该章节。"
  },
  {
    title: "网络题容易白丢分",
    text: "如果 DNS、URL、IP、安全、物联网总记不住，建议睡前只看网络概念清单，第二天再刷 20 题巩固。"
  }
];

const elements = {
  totalCount: document.getElementById("totalCount"),
  dailyProgressHero: document.getElementById("dailyProgressHero"),
  accuracyRate: document.getElementById("accuracyRate"),
  answeredCount: document.getElementById("answeredCount"),
  correctCount: document.getElementById("correctCount"),
  streakCount: document.getElementById("streakCount"),
  filteredCount: document.getElementById("filteredCount"),
  wrongCount: document.getElementById("wrongCount"),
  categoryFilters: document.getElementById("categoryFilters"),
  toggleAllCategoriesBtn: document.getElementById("toggleAllCategoriesBtn"),
  normalModeBtn: document.getElementById("normalModeBtn"),
  wrongModeBtn: document.getElementById("wrongModeBtn"),
  shuffleBtn: document.getElementById("shuffleBtn"),
  regenerateBtn: document.getElementById("regenerateBtn"),
  resetTodayBtn: document.getElementById("resetTodayBtn"),
  clearWrongBtn: document.getElementById("clearWrongBtn"),
  questionCategory: document.getElementById("questionCategory"),
  questionType: document.getElementById("questionType"),
  questionProgress: document.getElementById("questionProgress"),
  questionMode: document.getElementById("questionMode"),
  todayDateText: document.getElementById("todayDateText"),
  mobileProgressFill: document.getElementById("mobileProgressFill"),
  questionText: document.getElementById("questionText"),
  questionHint: document.getElementById("questionHint"),
  optionList: document.getElementById("optionList"),
  feedbackBox: document.getElementById("feedbackBox"),
  submitBtn: document.getElementById("submitBtn"),
  nextBtn: document.getElementById("nextBtn"),
  emptyState: document.getElementById("emptyState"),
  questionPanel: document.getElementById("questionPanel"),
  weeklyPlanGrid: document.getElementById("weeklyPlanGrid"),
  dynamicSummary: document.getElementById("dynamicSummary"),
  reviewAdvice: document.getElementById("reviewAdvice")
};

const categories = [...new Set(window.questionBank.map((item) => item.category))];
const todayKey = getTodayKey();

const defaultDailyStats = {
  answered: 0,
  correct: 0,
  streak: 0
};

let dailyStatsMap = loadJson(STORAGE_KEYS.dailyStatsMap, {});
let dailyStats = dailyStatsMap[todayKey] || { ...defaultDailyStats };
let wrongIds = new Set(loadJson(STORAGE_KEYS.wrongIds, []));
let selectedCategories = loadSelectedCategories();
let currentMode = localStorage.getItem(STORAGE_KEYS.mode) || "all";
let isShuffle = localStorage.getItem(STORAGE_KEYS.shuffle) !== "false";
let filteredQuestions = [];
let queue = [];
let currentQuestion = null;
let currentIndex = 0;
let locked = false;
let autoNextTimer = null;
let selectedAnswers = new Set();

renderCategoryFilters();
renderWeeklyPlan();
renderReviewAdvice();
bindEvents();
prepareQuestions(true);
renderStats();
renderDynamicSummary();
elements.todayDateText.textContent = `今天 ${todayKey}`;

function bindEvents() {
  elements.toggleAllCategoriesBtn.addEventListener("click", () => {
    const hasAll = selectedCategories.length === categories.length;
    selectedCategories = hasAll ? [categories[0]] : [...categories];
    persistUiState();
    renderCategoryFilters();
    prepareQuestions(true);
  });

  elements.normalModeBtn.addEventListener("click", () => {
    currentMode = "all";
    persistUiState();
    prepareQuestions(true);
  });

  elements.wrongModeBtn.addEventListener("click", () => {
    currentMode = "wrong";
    persistUiState();
    prepareQuestions(true);
  });

  elements.shuffleBtn.addEventListener("click", () => {
    isShuffle = !isShuffle;
    persistUiState();
    prepareQuestions(true);
  });

  elements.regenerateBtn.addEventListener("click", () => {
    prepareQuestions(true);
  });

  elements.resetTodayBtn.addEventListener("click", () => {
    dailyStats = { ...defaultDailyStats };
    saveDailyStats();
    renderStats();
    renderDynamicSummary();
  });

  elements.clearWrongBtn.addEventListener("click", () => {
    wrongIds.clear();
    saveJson(STORAGE_KEYS.wrongIds, []);
    prepareQuestions(true);
    renderStats();
    renderDynamicSummary();
  });

  elements.nextBtn.addEventListener("click", () => {
    showNextQuestion();
  });

  elements.submitBtn.addEventListener("click", () => {
    submitMultipleAnswer();
  });
}

function renderCategoryFilters() {
  elements.categoryFilters.innerHTML = "";

  categories.forEach((category) => {
    const button = document.createElement("button");
    const isActive = selectedCategories.includes(category);
    button.type = "button";
    button.className = `chip-btn${isActive ? " is-active" : ""}`;
    button.textContent = category;
    button.addEventListener("click", () => {
      toggleCategory(category);
      persistUiState();
      renderCategoryFilters();
      prepareQuestions(true);
    });
    elements.categoryFilters.appendChild(button);
  });

  const hasAll = selectedCategories.length === categories.length;
  elements.toggleAllCategoriesBtn.textContent = hasAll ? "取消全选" : "全选章节";
}

function prepareQuestions(resetIndex) {
  clearAutoNext();

  filteredQuestions = window.questionBank.filter((item) => {
    const categoryMatch = selectedCategories.includes(item.category);
    const modeMatch = currentMode === "all" || wrongIds.has(item.id);
    return categoryMatch && modeMatch;
  });

  queue = buildDailyQueue(filteredQuestions, DAILY_TARGET, isShuffle);

  if (resetIndex) {
    currentIndex = 0;
  } else if (currentIndex >= queue.length) {
    currentIndex = 0;
  }

  updateToolbarState();
  renderStats();
  showQuestionByIndex();
}

function buildDailyQueue(pool, target, shuffleMode) {
  if (pool.length === 0) {
    return [];
  }

  const source = shuffleMode ? shuffle([...pool]) : [...pool];
  const result = [];

  while (result.length < target) {
    const chunk = shuffleMode ? shuffle([...source]) : [...source];
    for (const item of chunk) {
      result.push(item);
      if (result.length >= target) {
        break;
      }
    }
  }

  return result;
}

function updateToolbarState() {
  elements.normalModeBtn.classList.toggle("is-active", currentMode === "all");
  elements.wrongModeBtn.classList.toggle("is-active", currentMode === "wrong");
  elements.shuffleBtn.classList.toggle("is-active", isShuffle);
  elements.questionMode.textContent = currentMode === "all" ? "全部题目" : "只刷错题";
}

function showQuestionByIndex() {
  if (queue.length === 0) {
    currentQuestion = null;
    elements.emptyState.classList.remove("hidden");
    elements.questionPanel.classList.add("hidden");
    elements.filteredCount.textContent = "0";
    elements.questionProgress.textContent = "第 0 / 0 题";
    return;
  }

  elements.emptyState.classList.add("hidden");
  elements.questionPanel.classList.remove("hidden");
  currentQuestion = queue[currentIndex];
  locked = false;
  selectedAnswers = new Set();

  elements.questionCategory.textContent = currentQuestion.category;
  elements.questionType.textContent = isMultipleQuestion(currentQuestion) ? "多选题" : "单选题";
  elements.questionProgress.textContent = `第 ${currentIndex + 1} / ${queue.length} 题`;
  elements.questionText.textContent = currentQuestion.question;
  elements.questionHint.textContent = isMultipleQuestion(currentQuestion)
    ? "多选题：可选择多个答案，选好后点击“提交答案”。"
    : "单选题：点击一个选项后自动判题。";
  elements.filteredCount.textContent = String(queue.length);
  elements.feedbackBox.className = "feedback-box hidden";
  elements.feedbackBox.innerHTML = "";
  elements.nextBtn.classList.add("hidden");
  elements.submitBtn.classList.toggle("hidden", !isMultipleQuestion(currentQuestion));
  elements.submitBtn.disabled = true;

  renderOptions();
}

function renderOptions() {
  const labels = ["A", "B", "C", "D"];
  elements.optionList.innerHTML = "";

  currentQuestion.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "option-btn";
    button.dataset.index = String(index);
    button.innerHTML = `<span class="option-label">${labels[index]}</span>${option}`;
    button.addEventListener("click", () => handleOptionClick(index));
    elements.optionList.appendChild(button);
  });
}

function handleOptionClick(selectedIndex) {
  if (locked || !currentQuestion) {
    return;
  }

  if (isMultipleQuestion(currentQuestion)) {
    toggleMultipleSelection(selectedIndex);
    return;
  }

  finalizeAnswer([selectedIndex]);
}

function toggleMultipleSelection(selectedIndex) {
  if (selectedAnswers.has(selectedIndex)) {
    selectedAnswers.delete(selectedIndex);
  } else {
    selectedAnswers.add(selectedIndex);
  }

  const optionButtons = [...elements.optionList.querySelectorAll(".option-btn")];
  optionButtons.forEach((button, index) => {
    button.classList.toggle("is-selected", selectedAnswers.has(index));
  });

  elements.submitBtn.disabled = selectedAnswers.size === 0;
}

function submitMultipleAnswer() {
  if (locked || !currentQuestion || !isMultipleQuestion(currentQuestion) || selectedAnswers.size === 0) {
    return;
  }

  finalizeAnswer([...selectedAnswers].sort((left, right) => left - right));
}

function finalizeAnswer(selectedIndexes) {
  if (locked || !currentQuestion) {
    return;
  }

  locked = true;
  clearAutoNext();

  const optionButtons = [...elements.optionList.querySelectorAll(".option-btn")];
  optionButtons.forEach((button) => button.classList.add("is-disabled"));

  const correctAnswers = getCorrectAnswers(currentQuestion);
  const isCorrect = answersEqual(selectedIndexes, correctAnswers);

  correctAnswers.forEach((answerIndex) => {
    optionButtons[answerIndex].classList.add("is-correct");
  });

  selectedIndexes.forEach((selectedIndex) => {
    if (!correctAnswers.includes(selectedIndex)) {
      optionButtons[selectedIndex].classList.add("is-wrong");
    }
  });

  dailyStats.answered += 1;

  if (isCorrect) {
    dailyStats.correct += 1;
    dailyStats.streak += 1;
    wrongIds.delete(currentQuestion.id);
    elements.feedbackBox.className = "feedback-box success";
    elements.feedbackBox.innerHTML = `<strong>回答正确。</strong> 解析：${currentQuestion.explanation}<br>1.2 秒后自动进入下一题。`;
    autoNextTimer = window.setTimeout(() => {
      showNextQuestion();
    }, 1200);
  } else {
    dailyStats.streak = 0;
    wrongIds.add(currentQuestion.id);
    elements.feedbackBox.className = "feedback-box error";
    elements.feedbackBox.innerHTML = `<strong>回答错误。</strong> 正确答案：${formatAnswerChoices(correctAnswers)}<br>解析：${currentQuestion.explanation}`;
    elements.nextBtn.classList.remove("hidden");
  }

  elements.submitBtn.classList.add("hidden");
  saveDailyStats();
  saveJson(STORAGE_KEYS.wrongIds, [...wrongIds]);
  renderStats();
  renderDynamicSummary();
}

function showNextQuestion() {
  clearAutoNext();

  if (queue.length === 0) {
    showQuestionByIndex();
    return;
  }

  currentIndex += 1;

  if (currentIndex >= queue.length) {
    currentIndex = 0;
  }

  showQuestionByIndex();
}

function renderStats() {
  const accuracy = dailyStats.answered === 0 ? 0 : Math.round((dailyStats.correct / dailyStats.answered) * 100);
  const todayDone = Math.min(dailyStats.answered, DAILY_TARGET);
  const progressPercent = `${Math.max(0, Math.min(100, todayDone))}%`;

  elements.totalCount.textContent = String(window.questionBank.length);
  elements.dailyProgressHero.textContent = `${todayDone} / ${DAILY_TARGET}`;
  elements.accuracyRate.textContent = `${accuracy}%`;
  elements.answeredCount.textContent = String(dailyStats.answered);
  elements.correctCount.textContent = String(dailyStats.correct);
  elements.streakCount.textContent = String(dailyStats.streak);
  elements.filteredCount.textContent = String(filteredQuestions.length === 0 ? 0 : queue.length);
  elements.wrongCount.textContent = String(wrongIds.size);
  elements.mobileProgressFill.style.width = progressPercent;
}

function renderWeeklyPlan() {
  elements.weeklyPlanGrid.innerHTML = "";

  weeklyPlan.forEach((item) => {
    const card = document.createElement("article");
    card.className = "plan-card";
    card.innerHTML = `
      <span class="plan-date">${item.date}</span>
      <h3>${item.title}</h3>
      <p><strong>重点章节：</strong>${item.focus}</p>
      <p>${item.summary}</p>
      <div class="plan-tag-list">
        ${item.tags.map((tag) => `<span class="plan-tag">${tag}</span>`).join("")}
      </div>
    `;
    elements.weeklyPlanGrid.appendChild(card);
  });
}

function renderDynamicSummary() {
  const wrongByCategory = categories
    .map((category) => ({
      category,
      count: window.questionBank.filter((item) => item.category === category && wrongIds.has(item.id)).length
    }))
    .sort((left, right) => right.count - left.count);

  const weakOne = wrongByCategory[0];
  const weakTwo = wrongByCategory[1];
  const accuracy = dailyStats.answered === 0 ? 0 : Math.round((dailyStats.correct / dailyStats.answered) * 100);

  let summary = `今天已完成 ${Math.min(dailyStats.answered, DAILY_TARGET)} / ${DAILY_TARGET} 题，正确率 ${accuracy}%。`;

  if (wrongIds.size === 0) {
    summary += " 当前还没有累计错题，建议继续按本周计划推进，做完 100 题后再回看速度最慢的章节。";
  } else if (weakOne && weakOne.count > 0) {
    summary += ` 当前最薄弱的是“${weakOne.category}”`;
    if (weakTwo && weakTwo.count > 0) {
      summary += `，其次是“${weakTwo.category}”`;
    }
    summary += "。建议明天优先多选这些章节，先回刷错题，再做新题。";
  }

  elements.dynamicSummary.innerHTML = `
    <strong>当前总结</strong>
    <p>${summary}</p>
  `;
}

function renderReviewAdvice() {
  elements.reviewAdvice.innerHTML = "";

  reviewAdvice.forEach((item) => {
    const card = document.createElement("article");
    card.className = "advice-card";
    card.innerHTML = `
      <h3>${item.title}</h3>
      <p>${item.text}</p>
    `;
    elements.reviewAdvice.appendChild(card);
  });
}

function persistUiState() {
  localStorage.setItem(STORAGE_KEYS.categories, JSON.stringify(selectedCategories));
  localStorage.setItem(STORAGE_KEYS.mode, currentMode);
  localStorage.setItem(STORAGE_KEYS.shuffle, String(isShuffle));
}

function saveDailyStats() {
  dailyStatsMap[todayKey] = dailyStats;
  saveJson(STORAGE_KEYS.dailyStatsMap, dailyStatsMap);
}

function clearAutoNext() {
  if (autoNextTimer) {
    window.clearTimeout(autoNextTimer);
    autoNextTimer = null;
  }
}

function saveJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function loadJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    return fallback;
  }
}

function shuffle(items) {
  for (let index = items.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [items[index], items[randomIndex]] = [items[randomIndex], items[index]];
  }
  return items;
}

function toChoice(index) {
  return ["A", "B", "C", "D"][index];
}

function formatAnswerChoices(indexes) {
  return indexes.map((index) => toChoice(index)).join("、");
}

function getCorrectAnswers(question) {
  return Array.isArray(question.answer) ? [...question.answer] : [question.answer];
}

function isMultipleQuestion(question) {
  return Array.isArray(question.answer) || question.type === "multiple";
}

function answersEqual(left, right) {
  if (left.length !== right.length) {
    return false;
  }

  const normalizedLeft = [...left].sort((a, b) => a - b);
  const normalizedRight = [...right].sort((a, b) => a - b);
  return normalizedLeft.every((item, index) => item === normalizedRight[index]);
}

function loadSelectedCategories() {
  const saved = loadJson(STORAGE_KEYS.categories, categories);
  const valid = saved.filter((item) => categories.includes(item));
  return valid.length > 0 ? valid : [...categories];
}

function toggleCategory(category) {
  if (selectedCategories.includes(category)) {
    if (selectedCategories.length === 1) {
      return;
    }
    selectedCategories = selectedCategories.filter((item) => item !== category);
  } else {
    selectedCategories = [...selectedCategories, category];
  }
}

function getTodayKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
